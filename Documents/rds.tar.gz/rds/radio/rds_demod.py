#!/usr/bin/env python

from gnuradio import blocks
from gnuradio import digital
from gnuradio import filter
from gnuradio import gr
from gnuradio.filter import firdes
import math
import numpy

class rds_demod(gr.hier_block2):

    def __init__(self, samp_rate):
        gr.hier_block2.__init__(
            self, "RDS demodulator",
            gr.io_signaturev(2, 2, [gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1]),
            gr.io_signature(1, 1, gr.sizeof_char*1),
        )

        ##################################################
        # Parameters
        ##################################################
        self.samp_rate = samp_rate

        ##################################################
        # Variables
        ##################################################
        self.decim = decim = int(samp_rate/(5*2400))

        ##################################################
        # Blocks
        ##################################################
        self.root_raised_cosine_filter = filter.fir_filter_ccf(decim, self.get_matched_filter_taps(6));
        self.differential_decoder = digital.diff_decoder_bb(2)
        self.carrier_recovery = digital.costas_loop_cc(2*math.pi/6000, 2, False)
        self.clock_recovery = digital.clock_recovery_mm_cc(samp_rate/decim/2375.0, 0.25*0.175*0.175, 0.5, 0.175, 0.005)
        self.slicer = digital.binary_slicer_fb()
        self.multiply = blocks.multiply_vcc(1)
        self.keep_1_in_2 = blocks.keep_one_in_n(gr.sizeof_char*1, 2)
        self.complex_to_real = blocks.complex_to_real(1)

        ##################################################
        # Connections
        ##################################################
        self.connect((self, 1), (self.multiply, 0))
        self.connect((self.complex_to_real, 0), (self.slicer, 0))
        self.connect((self.keep_1_in_2, 0), (self.differential_decoder, 0))
        self.connect((self.slicer, 0), (self.keep_1_in_2, 0))
        self.connect((self.differential_decoder, 0), (self, 0))
        self.connect((self.root_raised_cosine_filter, 0), (self.clock_recovery, 0))
        self.connect((self, 0), (self.multiply, 1))
        self.connect((self.clock_recovery, 0), (self.carrier_recovery, 0))
        self.connect((self.carrier_recovery, 0), (self.complex_to_real, 0))
        self.connect((self.multiply, 0), (self.root_raised_cosine_filter, 0))

    def get_matched_filter_taps(self, Ls):
        td=1/1187.5;    #Symbol duration
        L=int(Ls*td*self.samp_rate); #Filter length

        #Taps computation
        h=list();
        for k in range(0,L):
            w=4*(k/(td*self.samp_rate)-int(Ls/2));
            h.append((numpy.sinc(w + 0.5)+numpy.sinc(w - 0.5)));

        #Taps normalization
        return numpy.dot(h, 1/numpy.linalg.norm(h)).tolist();


    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.root_raised_cosine_filter.set_taps(self.get_matched_filter_taps(6))
        self.clock_recovery.set_omega(self.samp_rate/self.decim/2375.0)

    def get_decim(self):
        return self.decim

    def set_decim(self, decim):
        self.decim = decim
        self.clock_recovery.set_omega(self.samp_rate/self.decim/2375.0)

