#!/usr/bin/env python

import fm_audio_demod
import rds_demod

from gnuradio import analog
from gnuradio import blocks
from gnuradio import filter
from gnuradio import gr
from gnuradio.filter import firdes
import math

class fm_receiver(gr.hier_block2):
    def __init__(self, audio_rate, samp_rate):
        gr.hier_block2.__init__(
            self, "FM receiver",
            gr.io_signature(1, 1, gr.sizeof_gr_complex*1),
            gr.io_signaturev(3, 3, [gr.sizeof_char*1, gr.sizeof_float*1, gr.sizeof_float*1]),
        )

        ##################################################
        # Parameters
        ##################################################
        self.audio_rate = audio_rate
        self.samp_rate = samp_rate

        ##################################################
        # Blocks
        ##################################################
        self.rds_demod = rds_demod.rds_demod(samp_rate=samp_rate)
        # This filter should be removed if mpx_decimation == 1
        self.fm_audio_demod = fm_audio_demod.fm_audio_demod(
            samp_rate=samp_rate,audio_rate=audio_rate)
        self.multiply_L_minus_R_carrier = blocks.multiply_vcc(1)
        self.multiply_rds_carrier = blocks.multiply_vcc(1)
        self.float_to_complex = blocks.float_to_complex(1)
        self.filter_pilot_carrier = filter.fir_filter_ccf(1, firdes.band_pass(
        	1, samp_rate, 19e3-500, 19e3+500, 1e3, firdes.WIN_HAMMING, 6.76))
        self.filter_rds_carrier = filter.fir_filter_ccf(1, firdes.band_pass(
        	1, samp_rate, 57e3-500, 57e3+500, 1e3, firdes.WIN_HAMMING, 6.76))
        self.filter_L_minus_R_carrier = filter.fir_filter_ccf(1, firdes.band_pass(
        	1, samp_rate, 38e3-500, 38e3+500, 1e3, firdes.WIN_HAMMING, 6.76))
        self.fm_demod = analog.quadrature_demod_cf(1)
        self.pll = analog.pll_refout_cc(0.001, 2 * math.pi * (19000+200) / samp_rate, 2 * math.pi * (19000-200) / samp_rate)

        ##################################################
        # Connections
        ##################################################
        self.connect((self, 0), (self.fm_demod, 0))
        self.connect((self.fm_demod, 0), (self.float_to_complex, 0))
        self.connect((self.multiply_rds_carrier, 0), (self.filter_L_minus_R_carrier, 0))
        self.connect((self.filter_L_minus_R_carrier, 0), (self.fm_audio_demod, 1))
        self.connect((self.float_to_complex, 0), (self.fm_audio_demod, 0))
        self.connect((self.fm_audio_demod, 0), (self, 1))
        self.connect((self.fm_audio_demod, 1), (self, 2))
        self.connect((self.rds_demod, 0), (self, 0))
        self.connect((self.float_to_complex, 0), (self.rds_demod, 1))
        self.connect((self.multiply_L_minus_R_carrier, 0), (self.filter_rds_carrier, 0))
        self.connect((self.filter_rds_carrier, 0), (self.rds_demod, 0))
        self.connect((self.float_to_complex, 0), (self.filter_pilot_carrier, 0))
        self.connect((self.filter_pilot_carrier, 0), (self.pll, 0))
        self.connect((self.pll, 0), (self.multiply_rds_carrier, 0))
        self.connect((self.pll, 0), (self.multiply_rds_carrier, 1))
        self.connect((self.pll, 0), (self.multiply_L_minus_R_carrier, 0))
        self.connect((self.pll, 0), (self.multiply_L_minus_R_carrier, 1))
        self.connect((self.pll, 0), (self.multiply_L_minus_R_carrier, 2))

    def get_audio_rate(self):
        return self.audio_rate

    def set_audio_rate(self, audio_rate):
        self.audio_rate = audio_rate
        self.fm_audio_demod.set_audio_rate(self.audio_rate)

    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.fm_audio_demod.set_samp_rate(self.samp_rate)
        self.filter_L_minus_R_carrier.set_taps(firdes.band_pass(1, self.samp_rate, 38e3-500, 38e3+500, 1e3, firdes.WIN_HAMMING, 6.76))
        self.filter_rds_carrier.set_taps(firdes.band_pass(1, self.samp_rate, 57e3-500, 57e3+500, 1e3, firdes.WIN_HAMMING, 6.76))
        self.filter_pilot_carrier.set_taps(firdes.band_pass(1, self.samp_rate, 19e3-500, 19e3+500, 1e3, firdes.WIN_HAMMING, 6.76))
        self.rds_demod.set_samp_rate(self.samp_rate)
        self.pll.set_max_freq(2 * math.pi * (19000+200) / self.samp_rate)
        self.pll.set_min_freq(2 * math.pi * (19000-200) / self.samp_rate)
