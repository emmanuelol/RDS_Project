#!/usr/bin/env python

from gnuradio import analog
from gnuradio import blocks
from gnuradio import filter
from gnuradio import gr
from gnuradio.filter import firdes

class fm_audio_demod(gr.hier_block2):
    def __init__(self, samp_rate, audio_rate):
        gr.hier_block2.__init__(
            self, "FM audio demodulator",
            gr.io_signaturev(2, 2, [gr.sizeof_gr_complex*1, gr.sizeof_gr_complex*1]),
            gr.io_signaturev(2, 2, [gr.sizeof_float*1, gr.sizeof_float*1]),
        )

        ##################################################
        # Parameters
        ##################################################
        self.samp_rate = samp_rate
        self.audio_rate = audio_rate

        ##################################################
        # Variables
        ##################################################
        self.audio_decimation = audio_decimation = int(samp_rate/(2*16.5e3))

        ##################################################
        # Blocks
        ##################################################
        self.rational_resampler_0 = filter.rational_resampler_fff(
                interpolation=int(audio_rate),
                decimation=int(samp_rate/audio_decimation),
                taps=None,
                fractional_bw=None,
        )
        self.rational_resampler_1 = filter.rational_resampler_fff(
                interpolation=int(audio_rate),
                decimation=int(samp_rate/audio_decimation),
                taps=None,
                fractional_bw=None,
        )
        self.low_pass_filter_0 = filter.fir_filter_fff(audio_decimation, firdes.low_pass(
        	1, samp_rate, 15e3, 1.5e3, firdes.WIN_HAMMING, 6.76))
        self.low_pass_filter_1 = filter.fir_filter_fff(audio_decimation, firdes.low_pass(
        	1, samp_rate, 15e3, 1.5e3, firdes.WIN_HAMMING, 6.76))
        self.substract = blocks.sub_ff(1)
        self.multiply = blocks.multiply_vcc(1)
        self.complex_to_real_0 = blocks.complex_to_real(1)
        self.complex_to_real_1 = blocks.complex_to_real(1)
        self.add = blocks.add_vff(1)
        self.analog_fm_deemph_0 = analog.fm_deemph(fs=samp_rate/audio_decimation, tau=50e-6)
        self.analog_fm_deemph_1 = analog.fm_deemph(fs=samp_rate/audio_decimation, tau=50e-6)

        ##################################################
        # Connections
        ##################################################
        self.connect((self, 0), (self.complex_to_real_1, 0))
        self.connect((self.low_pass_filter_0, 0), (self.add, 0))
        self.connect((self.low_pass_filter_1, 0), (self.add, 1))
        self.connect((self.substract, 0), (self.analog_fm_deemph_0, 0))
        self.connect((self.add, 0), (self.analog_fm_deemph_1, 0))
        self.connect((self, 1), (self.multiply, 1))
        self.connect((self, 0), (self.multiply, 0))
        self.connect((self.multiply, 0), (self.complex_to_real_0, 0))
        self.connect((self.complex_to_real_1, 0), (self.low_pass_filter_0, 0))
        self.connect((self.complex_to_real_0, 0), (self.low_pass_filter_1, 0))
        self.connect((self.analog_fm_deemph_1, 0), (self.rational_resampler_1, 0))
        self.connect((self.rational_resampler_1, 0), (self, 0))
        self.connect((self.analog_fm_deemph_0, 0), (self.rational_resampler_0, 0))
        self.connect((self.rational_resampler_0, 0), (self, 1))
        self.connect((self.low_pass_filter_1, 0), (self.substract, 1))
        self.connect((self.low_pass_filter_0, 0), (self.substract, 0))
