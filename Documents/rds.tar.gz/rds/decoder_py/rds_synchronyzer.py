#!/usr/bin/env python

import rds_constants

class rds_synchronyzer(object):
    def __init__(self):
        self.bit_counter = 0;
        self.lastseen_offset_counter = 0;
        self.block_bit_counter = 0;
        self.wrong_blocks_counter = 0;
        self.blocks_counter = 0;
        self.group_good_blocks_counter = 0;
        self.group = [0, 0, 0, 0];
        self.last_good_group = [0, 0, 0, 0];
        self.presync = False;
        self.group_assembly_started = False;
        self.lastseen_offset = 0;
        self.block_number = 0;
        self.reg = 0;
        self.synced = False;

    def enter_no_sync(self):
	print "LOST SYNC !"
        self.presync = 0;
        self.synced = False;

    def enter_sync(self, sync_block_number):
	print "SYNCED !"
        self.wrong_blocks_counter = 0;
        self.blocks_counter = 0;
        self.block_bit_counter = 0;
        self.block_number = (sync_block_number + 1) % 4;
        self.group_assembly_started = 0;
        self.synced = True;

    def aquire_sync(self):
        i=0;
        reg_syndrome=0;
        bit_distance=0;
        block_distance=0;

        reg_syndrome = self.calc_syndrome(self.reg, 26);
        for i in range(0,5):
            if (reg_syndrome == rds_constants.syndrome[i]):
                if (self.presync == False):
                    self.lastseen_offset = i;
                    self.lastseen_offset_counter=self.bit_counter;
                    self.presync=True;
                else:
                    bit_distance = self.bit_counter - self.lastseen_offset_counter;

                    if (rds_constants.offset_pos[self.lastseen_offset] >= rds_constants.offset_pos[i]):
                        block_distance = rds_constants.offset_pos[i] + 4 - rds_constants.offset_pos[self.lastseen_offset];
                    else:
                        block_distance = rds_constants.offset_pos[i] - rds_constants.offset_pos[self.lastseen_offset];

                    if ((block_distance*26) != bit_distance):
                        self.presync = False;
                    else:
                        self.enter_sync(i);
                break; #syndrome found, no more cycles

    def calc_syndrome(self, message, mlen):
        reg = 0;
        i =0;
        poly = 0x5B9;
        plen = 10;

        for i in reversed(range(1, mlen+1)):
            reg = (reg << 1) | ((message >> (i-1)) & 0x01);
            if (reg & (1 << plen)):
                reg = reg ^ poly;

        for i in reversed(range(1, plen+1)):
            reg = reg << 1;
            if (reg & (1<<plen)):
                reg = reg ^ poly;

        return (reg & ((1<<plen)-1));	# select the bottom plen bits of reg

    #Meggit decoder, slightly modified version of the decoder proposed in the
    #standard, Annex B.2 p.75. This decoder is able to correct error of length 5
    #bits or less, and to detect if an uncorrectable error has occured.
    #This is suboptimal as the code allow the correction of errors spanning 10
    #bits or less.
    def correct_errors(self, seq, block_number):
        reg_syndrome = 0;
        syndrome10 = 0;
        bit = 0;
        error = 0;
        corrected_seq = 0;

        #Syndrome removal
        seq=seq ^ rds_constants.offset_word[block_number];

        #Decoding
        for i in range(1,26+16+1):
            syndrome10 = (reg_syndrome>>9)&1;

            if(i <= 26):
                bit=(seq>>(26-i))&1;
            else:
                bit=0;
                error = syndrome10 & \
                    ~((reg_syndrome&1) | ((reg_syndrome>>1)&1) \
                    | ((reg_syndrome>>2)&1) | ((reg_syndrome>>3)&1) \
                    | ((reg_syndrome>>4)&1));

                syndrome10 = syndrome10 ^ error;

                corrected_seq = corrected_seq<<1;
                corrected_seq = corrected_seq | (((seq>>((26+16+10)-i))&1) ^ error);

            reg_syndrome = (reg_syndrome<<1)&0x3FF; 
            reg_syndrome = reg_syndrome ^ (bit*0x31B) ^ (syndrome10*0x1B9);

        #Uncorrectable error detection
        if(reg_syndrome&0x1F != 0):
            corrected_seq=-1;

        return corrected_seq;

    def get_group(self):
        return self.last_good_group;

    def work(self, noutput_items, input_items):
        dataword=0;
        i=0;

        # the synchronization process is described in Annex C
        # page 66 of the standard
        while i<noutput_items:
            #reg contains the last 26 rds bits (last block)
            self.reg=(self.reg<<1)|(input_items[i]);
            #Limit the size of the register to 26 bits
            self.reg=self.reg&0x3FFFFFF;
            self.block_bit_counter = self.block_bit_counter + 1;

            if(self.synced == False):
                self.aquire_sync();
            else:
                # wait until 26 bits enter the buffer
                if(self.block_bit_counter == 26):
                    self.block_bit_counter = 0;

                    #Error correction and detection
                    corrected_seq=self.correct_errors(self.reg, self.block_number);
                    if(corrected_seq != -1):
                        dataword=corrected_seq;
                    # manage special case of C or C' offset word
                    elif ((self.block_number == 2)):
                        corrected_seq=self.correct_errors(self.reg, 4);
                        if(corrected_seq != -1):
                            dataword=corrected_seq;
                        else:
                            self.wrong_blocks_counter = self.wrong_blocks_counter + 1;
                    else:
                        self.wrong_blocks_counter = self.wrong_blocks_counter + 1;

                    # done checking CRC
                    if (self.block_number == 0 and corrected_seq != -1):
                        self.group_assembly_started = True;
                        self.group_good_blocks_counter = 1;

                    if (self.group_assembly_started):
                        if (corrected_seq == -1):
                            self.group_assembly_started = False;
                        else:
                            self.group[self.block_number] = dataword;
                            self.group_good_blocks_counter = self.group_good_blocks_counter + 1;
                            
                        if (self.group_good_blocks_counter == 5):
                            self.last_good_group = list(self.group);

                    self.block_number = (self.block_number + 1) % 4;
                    self.blocks_counter = self.blocks_counter + 1;

                    #1187.5 bps / 104 bits = 11.4 groups/sec, or 45.7 blocks/sec */
                    if (self.blocks_counter==50):
                        if (self.wrong_blocks_counter>35):
                            #Lost sync
                            self.enter_no_sync();

                        self.blocks_counter=0;
                        self.wrong_blocks_counter=0;

            i=i+1;
            self.bit_counter = self.bit_counter + 1;
