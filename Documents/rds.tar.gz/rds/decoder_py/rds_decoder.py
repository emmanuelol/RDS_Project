#!/usr/bin/env python

import rds_synchronyzer as sync
import rds_constants
import tmc_events

class rds_decoder(object):
    def __init__(self):
        self.group = [0, 0, 0, 0];
        self.synchronyzer = sync.rds_synchronyzer();

        self.program_identification = 0;
        self.program_type = 0

        self.pi_country_identification = 0;
        self.pi_area_coverage = 0;
        self.pi_program_reference_number = 0;

        self.radiotext_AB_flag = False;
        self.radiotext = [];
        for i in range(0, 65):
            self.radiotext.append(' ');

        self.program_service_name = [];
        for i in range(0, 8):
            self.program_service_name.append(None);

        self.ps_on= [];
        for i in range(0, 8):
            self.ps_on.append(' ');

        self.traffic_program = False;
        self.traffic_announcement = False;
        self.music_speech = False;
        self.mono_stereo = False;
        self.artificial_head = False;
        self.compressed = False;
        self.static_pty = False;

    def decode_group(self, group):
        group_type = ((group[1] >> 12) & 0xf);
        ab = (group[1] >> 11 ) & 0x1;

        self.program_identification = group[0];     # "PI"
        self.program_type = (group[1] >> 5) & 0x1f; # "PTY"
        self.traffic_program = (group[1] >> 10) & 0x01;       # "TP"
        self.pi_country_identification = (self.program_identification >> 12) & 0xf;
        self.pi_area_coverage = (self.program_identification >> 8) & 0xf;
        self.pi_program_reference_number = self.program_identification & 0xff;

        print "\nPI:",;
        print self.program_identification,;
        print "- PTY:",;
        print rds_constants.pty_table[self.program_type],;

        print " (country:",;
        print rds_constants.pi_country_codes[self.pi_country_identification - 1][0],;
        print "/",;
        print rds_constants.pi_country_codes[self.pi_country_identification - 1][1],;
        print "/",;
        print rds_constants.pi_country_codes[self.pi_country_identification - 1][2],;
        print "/",;
        print rds_constants.pi_country_codes[self.pi_country_identification - 1][3],;
        print "/",;
        print rds_constants.pi_country_codes[self.pi_country_identification - 1][4],;

        print ", area:",;
        print rds_constants.coverage_area_codes[self.pi_area_coverage],;
        print ", program:",;
        print self.pi_program_reference_number,;
        print ")";

        if(group_type == 0):
            self.decode_type0(group, ab);
        elif(group_type == 1):
            self.decode_type1(group, ab);
        elif(group_type == 2):
            self.decode_type2(group, ab);
        elif(group_type == 3):
            self.decode_type3(group, ab);
        elif(group_type == 4):
            self.decode_type4(group, ab);
        elif(group_type == 5):
            self.decode_type5(group, ab);
        elif(group_type == 6):
            self.decode_type6(group, ab);
        elif(group_type == 7):
            self.decode_type7(group, ab);
        elif(group_type == 8):
            self.decode_type8(group, ab);
        elif(group_type == 9):
            self.decode_type9(group, ab);
        elif(group_type == 10):
            self.decode_type10(group, ab);
        elif(group_type == 11):
            self.decode_type11(group, ab);
        elif(group_type == 12):
            self.decode_type12(group, ab);
        elif(group_type == 13):
            self.decode_type13(group, ab);
        elif(group_type == 14):
            self.decode_type14(group, ab);
        elif(group_type == 15):
            self.decode_type15(group, ab);

    def work(self, noutput_items, input_items):
        new_group = [0, 0, 0, 0];

        self.synchronyzer.work(noutput_items, input_items);
        new_group = self.synchronyzer.get_group();

        if(new_group != self.group):
            self.group = list(new_group);
            self.decode_group(self.group);

    def decode_type0(self, group, B):
        af_code_1 = 0;
        af_code_2 = 0;
        no_af = 0;
        af_1 = 0;
        af_2 = 0;
        program_service_name_received=True;

        self.traffic_announcement   = (group[1] >>  4) & 0x01;       # "TA"
        self.music_speech           = (group[1] >>  3) & 0x01;       # "MuSp"

        decoder_control_bit = (group[1] >> 2) & 0x01; # "DI"
        segment_address = group[1] & 0x03;       # "DI segment"

        self.program_service_name[segment_address * 2]     = chr((group[3] >> 8) & 0xff);
        self.program_service_name[segment_address * 2 + 1] = chr(group[3] & 0xff);

        # see page 41, table 9 of the standard
        if(segment_address==0):
            self.mono_stereo=decoder_control_bit;
        elif(segment_address==1):
            self.artificial_head=decoder_control_bit;
        elif(segment_address==2):
            self.compressed=decoder_control_bit;
        elif(segment_address==3):
            self.static_pty=decoder_control_bit;

        if(not B): # type 0A
            af_code_1 = (group[2] >> 8) & 0xff;
            af_code_2 = (group[2])      & 0xff;
            af_1 = self.decode_af(af_code_1);
            af_2 = self.decode_af(af_code_2);

            if(af_1):
                no_af += 1;
            if(af_2):
                no_af += 2;

        #Only display program name if we received it entirely
        for i in range(0, 8):
            if(self.program_service_name[i] == None):
                program_service_name_received=False;
                break;

        if(program_service_name_received == True):
            print "==>",;
            print ''.join(self.program_service_name),;
            print "<== -",;

        if (self.traffic_program):
            print "TP -",;
        if (self.traffic_announcement):
            print "TA -",;
        print "Music -" if self.music_speech else "Speech -",;
        print "MONO" if self.mono_stereo else "STEREO",;

        if(no_af==1):
            print "- AF:",;
            print af_1,;
            print "kHz";
        if(no_af==2):
            print "- AF:",;
            print af_2,;
            print "kHz";
        if(no_af==3):
            print "- AF:",;
            print af_1,;
            print "kHz,",;
            print af_2,;
            print "kHz";
        else:
            print '\n',;

    def decode_af(self, af_code):
        number_of_freqs = 0;
        vhf_or_lfmf = 0; # 0 = vhf, 1 = lf/mf
        alt_frequency = 0; # in kHz

        if((af_code == 0) or                            # not to be used
            ( af_code == 205) or                        # filler code
            ((af_code >= 206) and (af_code <= 223)) or  # not assigned
            ( af_code == 224) or                        # No AF exists
            ( af_code >= 251)):                         # not assigned
                number_of_freqs = 0;
                alt_frequency   = 0;

        if((af_code >= 225) and (af_code <= 249)):      # VHF frequencies follow
            number_of_freqs = af_code - 224;
            alt_frequency   = 0;
            vhf_or_lfmf     = 1;

        if(af_code == 250):                             # an LF/MF frequency follows
            number_of_freqs = 1;
            alt_frequency   = 0;
            vhf_or_lfmf     = 0;

        if((af_code > 0) and (af_code < 205) and vhf_or_lfmf):
            alt_frequency = 100.0 * (af_code + 875);          # VHF (87.6-107.9MHz)
        elif((af_code > 0) and (af_code < 16) and not vhf_or_lfmf):
            alt_frequency = 153.0 + (af_code - 1) * 9;        # LF (153-279kHz)
        elif((af_code > 15) and (af_code < 136) and not vhf_or_lfmf):
            alt_frequency = 531.0 + (af_code - 16) * 9 + 531; # MF (531-1602kHz)

        return alt_frequency;

    def decode_type1(self, group, B):
        ecc = 0;
        paging = 0;
        country_code = (group[0] >> 12) & 0x0f;

        radio_paging_codes =  group[1] & 0x1f;

        variant_code = (group[2] >> 12) & 0x7;
        slow_labelling = group[2] & 0xfff;

        day = (group[3] >> 11) & 0x1f;
        hour = (group[3] >>  6) & 0x1f;
        minute = group[3] & 0x3f;

        if(radio_paging_codes):
            print "Paging codes:",;
            print radio_paging_codes,;

        if(day or hour or minute):
            print "Program item:",;
            print day,;
            print hour,;
            print minute,;

        if(not B):
            if(variant_code==0): # paging + ecc
                paging = (slow_labelling >> 8) & 0x0f;
                ecc    =  slow_labelling       & 0xff;
                if(paging):
                    print "paging:",;
                    print paging,;
                if((ecc > 223) and (ecc < 229)):
                    print "extended country code:",;
                    print pi_country_codes[country_code-1][ecc-224],;
                else:
                    print "invalid extended country code:",;
                    print ecc,;
            if(variant_code==1): # TMC identification
                print "TMC identification code received";
            if(variant_code==2): # Paging identification
                print "Paging identification code received";
            if(variant_code==3): # language codes
                if(slow_labelling < 44):
                    print "language:",;
                    print language_codes[slow_labelling],;
                else:
                    print "language: invalid language code",;
                    print slow_labelling,;

    def decode_type2(self, group, B):
        text_segment_address_code = group[1] & 0x0f;

        # when the A/B flag is toggled, flush your current radiotext
        if(self.radiotext_AB_flag != ((group[1] >> 4) & 0x01)):
            for i in range(0, 26):
                self.radiotext[i] = ' ';

        self.radiotext_AB_flag = (group[1] >> 4) & 0x01;

        if(not B):
            self.radiotext[text_segment_address_code *4     ] = chr((group[2] >> 8) & 0xff);
            self.radiotext[text_segment_address_code * 4 + 1] = chr(group[2] & 0xff);
            self.radiotext[text_segment_address_code * 4 + 2] = chr((group[3] >> 8) & 0xff);
            self.radiotext[text_segment_address_code * 4 + 3] = chr(group[3] & 0xff);
        else:
            self.radiotext[text_segment_address_code * 2    ] = chr((group[3] >> 8) & 0xff);
            self.radiotext[text_segment_address_code * 2 + 1] = chr(group[3] & 0xff);

        print "Radio Text",;
        print 'B' if self.radiotext_AB_flag else 'A',;
        print ":",
        print ''.join(self.radiotext);

    def decode_type3(self, group, B):
        if(B):
            print "type 3B not implemented yet";
            return;

        application_group = (group[1] >> 1) & 0xf;
        group_type        =  group[1] & 0x1;
        message           =  group[2];
        aid               =  group[3];

        print "Aid group:",;
        print application_group,;
        print 'B' if group_type else 'A';

        if((application_group == 8) and (group_type == 0)): # 8A
            variant_code = (message >> 14) & 0x3;
            if(variant_code == 0):
                ltn  = (message >> 6) & 0x3f; # location table number
                afi = (message >> 5) & 0x1;  # alternative freq. indicator
                M   = (message >> 4) & 0x1;  # mode of transmission
                I   = (message >> 3) & 0x1;  # international
                N   = (message >> 2) & 0x1;  # national
                R   = (message >> 1) & 0x1;  # regional
                U   =  message       & 0x1;  # urban
                print "Location table:",;
                print ltn,;
                print "-",;
                print "AFI-ON" if afi else "AFI-OFF",;
                print "-",;
                print "enhanced mode" if M else "basic mode",;
                print "-",;
                print "international" if I else '',;
                print "national" if N else '',;
                print "regional" if R else '',;
                print "urban" if U else '',;
                print "aid:",;
                print aid;
            elif(variant_code==1):
                G   = (message >> 12) & 0x3;  # gap
                sid = (message >>  6) & 0x3f; # service identifier
                gap_no = [3, 5, 8, 11];
                print "Gap:",;
                print gap_no[G],;
                print "groups, SID",;
                print sid;

        print "Message:",;
        print message,;
        print "- aid:",;
        print aid;

    def decode_type4(self, group, B):
        if(B):
            print "type 4B not implemented yet";
            return;

        hours   = ((group[2] & 0x1) << 4) | ((group[3] >> 12) & 0x0f);
        minutes =  (group[3] >> 6) & 0x3f;
        local_time_offset = .5 * (group[3] & 0x1f);

        if((group[3] >> 5) & 0x1):
                local_time_offset *= -1;

        modified_julian_date = ((group[1] & 0x03) << 15)| ((group[2] >> 1) & 0x7fff);

        year  = int((modified_julian_date - 15078.2) / 365.25);
        month = int((modified_julian_date - 14956.1 - (year * 365.25)) / 30.6001);
        day   = modified_julian_date - 14956 - int(year * 365.25) - int(month * 30.6001);
        K = 1 if ((month == 14) or (month == 15)) else 0;
        year += K;
        month -= 1 + K * 12;

        print "Clocktime:",;
        print day,;
        print month,;
        print (1901 + year),;
        print ",",;
        print hours,;
        print minutes,;
        print "(",;
        print local_time_offset,;
        print ")";

    def decode_type5(self, group, B):
        print "type 5 not implemented yet";

    def decode_type6(self, group, B):
        print "type 6 not implemented yet";

    def decode_type7(self, group, B):
        print "type 7 not implemented yet";

    def decode_type8(self, group, B):
        if(B):
            print "type 8B not implemented yet";
            return;

        T = (group[1] >> 4) & 0x1; # 0 = user message, 1 = tuning info
        F = (group[1] >> 3) & 0x1; # 0 = multi-group, 1 = single-group
        D = (group[2] > 15) & 0x1; # 1 = diversion recommended
        free_format = [0, 0, 0, 0];
        no_groups = 0;

        if(T): # tuning info
            print "#tuning info# ";
            variant = group[1] & 0xf;
            if((variant > 3) and (variant < 10)):
                print "variant:",;
                print variant,;
                print "-",;
                print group[2],;
                print group[3];
            else:
                print "invalid variant:",;
                print variant;

        elif(F or D): # single-group or 1st of multi-group
            dp_ci    =  group[1]        & 0x7;   # duration & persistence or continuity index
            sign     = (group[2] >> 14) & 0x1;   # event direction, 0 = +, 1 = -
            extent   = (group[2] >> 11) & 0x7;   # number of segments affected
            event    =  group[2]        & 0x7ff; # event code, defined in ISO 14819-2
            location =  group[3];                # location code, defined in ISO 14819-3

            print "#user msg#",;
            print "diversion recommended, " if D else "",;
            if(F):
                print "single-grp, duration:",;
                print rds_constants.tmc_duration[dp_ci][0],;
            else:
                print "multi-grp, continuity index:",;
                print dp_ci,;

            if(event <= 1590):
                event_line = tmc_events.tmc_event_code_index[event][1];
                print ", extent:",;
                print "-" if sign else '',;
                print extent + 1,;
                print "segments",;
                print ", event",;
                print event,;
                print ":",;
                print tmc_events.tmc_events[event_line][1],;
                print ", location:",;
                print location;

        else: # 2nd or more of multi-group
            ci = group[1] & 0x7;          # countinuity index
            sg = (group[2] >> 14) & 0x1;          # second group
            gsi = (group[2] >> 12) & 0x3; # group sequence

            print "#user msg# multi-grp, continuity index:",;
            print ci,;
            print "second group" if sg else '',;
            print ", gsi:",;
            print gsi,;
            print ", free format:",;
            print group[2] & 0xfff,;
            print group[3];

            # it's not clear if gsi=N-2 when gs=true
            if(sg):
                no_groups = gsi;

            free_format[gsi] = ((group[2] & 0xfff) << 12) | group[3];
            if(gsi == 0):
                self.decode_optional_content(no_groups, free_format);

    def decode_optional_content(self, no_groups, free_format):
        label	        = 0;
        content	        = 0;
        content_length	= 0;
        ff_pointer      = 0;
        i		        = 0;

        i = no_groups;
        while(i==0):
            ff_pointer = 12 + 16;
            while(ff_pointer > 0):
                ff_pointer = ff_pointer - 4;
                label = (free_format[i] and (0xf << ff_pointer));
                content_length = optional_content_lengths[label];
                ff_pointer = ff_pointer - content_length;
                content = (free_format[i] and (int((pow(2, content_length)) - 1) << ff_pointer));

                print "TMC optional content (",;
                print label_descriptions[label],;
                print ")",;
                print content;
            i = i-1;

    def decode_type9(self, group, B):
        print "type 9 not implemented yet";

    def decode_type10(self, group, B):
        print "type 10 not implemented yet";

    def decode_type11(self, group, B):
        print "type 11 not implemented yet";

    def decode_type12(self, group, B):
        print "type 12 not implemented yet";

    def decode_type13(self, group, B):
        print "type 13 not implemented yet";

    def decode_type14(self, group, B):
        tp_on       = (group[1] >> 4) & 0x01;
        variant_code= group[1] & 0x0f;
        information = group[2];
        pi_on       = group[3];

        pty_on = 0;
        ta_on = 0;
        af_1 = 0;
        af_2 = 0;

        if (not B):
            if (variant_code >= 0 and variant_code <= 3):# PS(ON)
                self.ps_on[variant_code * 2    ] = chr((information >> 8) & 0xff);
                self.ps_on[variant_code * 2 + 1] = chr(information       & 0xff);
                print "PS(ON): ==>",;
                print ''.join(self.ps_on),;
                print "<==",;

            elif (variant_code == 4): # AF
                af_1 = 100.0 * (((information >> 8) & 0xff) + 875);
                af_2 = 100.0 * ((information & 0xff) + 875);
                print "AF:",;
                print af_1/1000,;
                print "MHz",;
                print af_2/1000,;
                print "MHz",;

            elif (variant_code >= 5 and variant_code <= 8): # mapped frequencies
                af_1 = 100.0 * (((information >> 8) & 0xff) + 875);
                af_2 = 100.0 * ((information & 0xff) + 875);
                print "TN:",;
                print af_1/1000,;
                print "MHz",;
                print "- ON:",;
                print af_2/1000,;
                print "MHz",;

            elif (variant_code == 9): # mapped frequencies (AM)
                af_1 = 100.0 * (((information >> 8) & 0xff) + 875);
                af_2 = 9.0 * ((information & 0xff) - 16) + 531;
                print "TN:",;
                print af_1/1000,;
                print "MHz",;
                print "- ON:",;
                print af_2/1000,;
                print "kHz",;

            elif (variant_code == 12): # linkage information
                print "Linkage information:",;
                print (information >> 8) & 0xff,;
                print information & 0xff,;

            elif (variant_code == 13): # PTY(ON), TA(ON)
                ta_on = information & 0x01;
                pty_on = (information >> 11) & 0x1f;
                print "PTY(ON):",;
                print rds_constants.pty_table[int(pty_on)],;

                if(ta_on):
                    print " - TA";

            elif (variant_code == 14): # PIN(ON)
                print "PIN(ON):",;
                print (information >> 8) & 0xff,;
                print information & 0xff;

            else:
                print "invalid variant code:",;
                print variant_code,;

        if (pi_on):
            print " PI(ON):",;
            print pi_on,;
            if (tp_on):
                print "-TP-",;

        print '\n';

    def decode_type15(self, group, B):
        print "type 15 not implemented yet";

    def decode_type15(self, group, B):
        print "type 15 not implemented yet";

if __name__ == '__main__':
    f = open("/localdata/marqueal/Documents/sdr/alex-rds/radio/grc/rds_data.dat", "rb");

    decoder = rds_decoder();

    try:
		while True:
			read_bits = f.read(8);
			if not read_bits:
				break;

			bits=[];
			for item in read_bits:
				bits.append(ord(item));

			decoder.work(len(bits), bits);
    finally:
        f.close();
